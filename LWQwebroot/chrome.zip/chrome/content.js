console.log("hello")


// Website API soon


// opens a communication between scripts
var port = chrome.runtime.connect()
port.disconnect()
port = chrome.runtime.connect()

console.log(port)